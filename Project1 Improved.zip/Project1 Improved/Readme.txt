Rylan Casanova
02/26/23
CST-315
Project 1: Improved Unix/Linux Command Line Interpreter


***NECESSARY LIBRARY INSTALLATION***

run "sudo apt-get install libreadline-dev" to install readline library


Instructions for compiling/running CLI2.cpp (improved command line interpreter)

1. Move CLI2.cpp to the current directory
2. Compile CLI.cpp by executing the following command: "g++ CLI2.cpp -o cli2 -lreadline"
3. Run CLI2.cpp by executing the following command: "./cli"
4. Type a Unix/Linux command in the shell terminal and hit "Enter" to run the command
5. Use a semicolon to separate and run multiple different commands
6. Use the Up/Down Arrow keys to navigate through the history of previously run commands
7. Use CTRL+C or CTRL+D to exit the shell